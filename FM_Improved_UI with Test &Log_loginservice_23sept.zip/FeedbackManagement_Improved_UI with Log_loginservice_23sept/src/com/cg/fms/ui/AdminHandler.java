package com.cg.fms.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.fms.dto.Course;
import com.cg.fms.dto.Employee;
import com.cg.fms.dto.FacultySkill;
import com.cg.fms.dto.Feedback;
import com.cg.fms.dto.Training;
import com.cg.fms.exception.FMSException;
import com.cg.fms.service.CourseService;
import com.cg.fms.service.CourseServiceImpl;
import com.cg.fms.service.EmployeeService;
import com.cg.fms.service.EmployeeServiceImpl;
import com.cg.fms.service.FacultySkillService;
import com.cg.fms.service.FacultySkillServiceImpl;
import com.cg.fms.service.FeedbackService;
import com.cg.fms.service.FeedbackServiceImpl;
import com.cg.fms.service.ParticipantEnrollmentService;
import com.cg.fms.service.ParticipantEnrollmentServiceImpl;
import com.cg.fms.service.TrainingService;
import com.cg.fms.service.TrainingServiceImpl;

public class AdminHandler {

	Employee admin;
	CourseService courseService = null;
	ParticipantEnrollmentService partcipantEService = null;
	TrainingService trainingService = null;
	FeedbackService feedbackService = null;
	EmployeeService employeeService = null;
	FacultySkillService facultySkillService = null;

	public AdminHandler(Employee employee) {
		super();
		admin = employee;
		courseService = new CourseServiceImpl();
		partcipantEService = new ParticipantEnrollmentServiceImpl();
		trainingService = new TrainingServiceImpl();
		feedbackService = new FeedbackServiceImpl();
		employeeService = new EmployeeServiceImpl();
		facultySkillService = new FacultySkillServiceImpl();
	}

	public void start() throws FMSException {
		System.out.println("*****************************************");
		System.out.println("Welcome " + admin.getEmployeeName());
		System.out.println("You are logged in as ADMIN");
		System.out.println("What do you want to do");
		System.out.println("1.Faculty skill Maintenance\r\n" + "2.Course Maintenance\r\n" + "3.View Feedback Report\r\n"
				+ "4.Logout\n");
		// all menu items, switch case

		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();

		switch (choice) {
		case 1:
			displayFacultySkillPage();
			break;

		case 2:
			displayCourseMainPage();
			break;

		case 3:
			displayFeedbackReportPage();
			break;

		case 4:
			MainClass.main(null);

		default:
			break;
		}

	}

	public void displayCourseMainPage() throws FMSException {
		Scanner sc = new Scanner(System.in);
		boolean flag = true;

		do {
			System.out.println("\nWelcome to Course Maintenance page");
			System.out.println("What do you want to do");
			System.out.println("1.Get All Courses\n2.Add Course\n3.Edit Course\n4.Exit");

			int key = sc.nextInt();

			switch (key) {
			case 1:
				ArrayList<Course> courseList = courseService.getAllCourse();
				for (Course course : courseList) {
					System.out.println(
							course.getCourseId() + "\t" + course.getCourseName() + "\t" + course.getNoOfDays());
				}
				break;

			case 2:
				System.out.println("Enter course name : ");
				String courseName = sc.next();
				System.out.println("Enter course duration : ");
				int courseDuration = sc.nextInt();
				Course newCourse = new Course(courseName, courseDuration);
				Course addedCourse = courseService.addCourse(newCourse);
				if (addedCourse != null) {
					System.out.println("Course Successfully added.");
				} else {
					System.out.println("Not added");
				}
				break;

			case 3:
				System.out.println("Enter Course Id : ");
				int id = sc.nextInt();
				Course course = courseService.getCourseById(id);
				if (employeeService.validateId(id)) {
					if (course != null) {
						editCourse(course);
					} else
						System.out.println("Course Not Found");
				} else
					System.out.println("Course Id not valid");

				break;

			case 4:
				flag = false;
				start();
				break;

			default:
				break;
			}
		} while (flag);

	}

	public void editCourse(Course course) throws FMSException {
		Scanner sc = new Scanner(System.in);
		System.out.println(course);
		boolean flag = true;
		do {
			System.out.println("What do you want to edit?");
			System.out.println("1.Course Name\n2.Course Duration\n3.Exit");
			int ch1 = sc.nextInt();
			switch (ch1) {
			case 1:
				System.out.println("Enter updated course name : ");
				String CourseName = sc.next();
				Course editedCourse1 = new Course(course.getCourseId(), CourseName, course.getNoOfDays());
				Course newCourse1 = courseService.updateCourse(editedCourse1);
				if (newCourse1 != null) {
					System.out.println("Updated");
				} else {
					System.out.println("Not updated");
				}
				break;

			case 2:
				System.out.println("Enter updated duration : ");
				int courseDuration = sc.nextInt();
				Course editedCourse2 = new Course(course.getCourseId(), course.getCourseName(), courseDuration);
				Course newCourse2 = courseService.updateCourse(editedCourse2);
				if (newCourse2 != null) {
					System.out.println("Updated");
				} else {
					System.out.println("Not updated");
				}
				break;

			case 3:
				flag = false;
				break;

			default:
				break;

			}
		} while (flag);

	}

	public void displayFeedbackReportPage() throws FMSException {
		boolean flag = true;
		Scanner sc = new Scanner(System.in);

		do {
			System.out.println("\nWelcome to Feedback Report page");
			System.out.println("What do you want to do");
			System.out.println(
					"1.View Feedback for All Training Programs\n2.Average Feedback For Selected Month\n3.Facultywise Feedback\n4.Feedback Defaulters Details\n5.Exit");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				viewFeedBack();
				break;
			case 2:
				AverageFeedback();
				break;
			case 3:
				facultyWiseAverageFeedback();
				break;
			case 4:
				feedbackDefaulters();
				break;
			case 5:
				flag = false;
				start();
				break;

			default:
				break;
			}
		} while (flag);

	}

	private void viewFeedBack() throws FMSException {

		ArrayList<Feedback> feedback = feedbackService.getAllFeedbacks();
		Iterator<Feedback> it = feedback.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}

	}

	private void AverageFeedback() throws FMSException {
		System.out.println("Enter a Month");
		Scanner sc = new Scanner(System.in);
		int month = sc.nextInt();
		if (month <= 12) {
			ArrayList feedback = feedbackService.joinTrainingWithFeed(month);
			// System.out.println(feedback);
			int presentation = 0;
			int clarifyDoubts = 0;
			int timeMgt = 0;
			int hwAndSw = 0;
			int handOut = 0;
			if (feedback.size() > 0) {
				for (int i = 3; i < feedback.size(); i = i + 8) {
					presentation = presentation + (int) feedback.get(i);
					clarifyDoubts = clarifyDoubts + (int) feedback.get(i + 1);
					timeMgt = timeMgt + (int) feedback.get(i + 2);
					handOut = handOut + (int) feedback.get(i + 3);
					hwAndSw = hwAndSw + (int) feedback.get(i + 4);

				}
				int size = feedback.size() / 8;
				System.out.println("Average score for presentation :" + presentation / size);
				System.out.println("Average score for Clarify Doubts :" + clarifyDoubts / size);
				System.out.println("Average score for Time Management :" + timeMgt / size);
				System.out.println("Average score for HandOut :" + handOut / size);
				System.out.println("Average score for Hardware and Software : " + hwAndSw / size);
			} else
				System.out.println("No record found for this month");
		} else
			System.out.println("Enter a valid Month");
	}

	private void facultyWiseAverageFeedback() throws FMSException {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Faculty Code");
		int fc = sc.nextInt();
		if (employeeService.validateId(fc)) {
			if (employeeService.getEmployeeById(fc).getRole().equalsIgnoreCase("trainer")) {
				System.out.println("Enter a Month");
				int month = sc.nextInt();
				if (month <= 12) {
					ArrayList feedback = feedbackService.facultyFeedback(fc, month);

					int presentation = 0;
					int clarifyDoubts = 0;
					int timeMgt = 0;
					int hwAndSw = 0;
					int handOut = 0;
					if (feedback != null && feedback.size() > 0) {
						for (int i = 2; i < feedback.size(); i = i + 7) {
							presentation = presentation + (int) feedback.get(i);
							clarifyDoubts = clarifyDoubts + (int) feedback.get(i + 1);
							timeMgt = timeMgt + (int) feedback.get(i + 2);
							handOut = handOut + (int) feedback.get(i + 3);
							hwAndSw = hwAndSw + (int) feedback.get(i + 4);

						}
						int size = feedback.size() / 7;
						// int size = feedback.size();
						System.out.println(size);
						System.out.println("Average score for presentation :" + presentation / size);
						System.out.println("Average score for Clarify Doubts :" + clarifyDoubts / size);
						System.out.println("Average score for Time Management :" + timeMgt / size);
						System.out.println("Average score for HandOut :" + handOut / size);
						System.out.println("Average score for Hardware and Software : " + hwAndSw / size);
					} else
						System.out.println("No record found for this month");
				} else
					System.out.println("Enter a valid Month");
			} else
				System.out.println("Faculty Code does not exist.");
		} else
			System.out.println("Faculty Code not valid.");
	}

	private void feedbackDefaulters() throws FMSException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Month");
		int month = sc.nextInt();
		if (month <= 12) {
			ArrayList feedback = feedbackService.defaultersFeedback(month);
			if (feedback.size() > 0) {
				Iterator it = feedback.iterator();
				while (it.hasNext()) {
					System.out.println(it.next());
				}
			} else
				System.out.println("No record found for this month");
		} else
			System.out.println("Enter the Valid Month");
	}

	public void displayFacultySkillPage() throws FMSException {

		ArrayList<FacultySkill> facultySkillList = facultySkillService.getAllFacultySkills();
		ArrayList<Course> courseList = courseService.getAllCourse();
		while (true) {
			System.out.println("\nWelcome to Faculty Skill Maintenance page");
			System.out.println("What do you want to do?\n1.Show Faculty Skill List\n" + "2.Show Course List\n"
					+ "3.Add Training Course\n" + "4.Exit");
			Scanner sc = new Scanner(System.in);
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				for (FacultySkill facultyskill : facultySkillList) {
					System.out.println(facultyskill.getFacultyId() + "\t"
							+ employeeService.getEmployeeById(facultyskill.getFacultyId()).getEmployeeName() + "\t"
							+ facultyskill.getSkillSet());
				}
				break;

			case 2:
				for (Course course : courseList) {
					System.out.println(
							course.getCourseId() + "\t" + course.getCourseName() + "\t" + course.getNoOfDays());
				}
				break;

			case 3:
				addTrain();
				break;

			case 4:
				start();

			default:
				break;
			}
		}

	}

	public void addTrain() throws FMSException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Faculty Id : ");
		int FacultyId = sc.nextInt();
		if (employeeService.validateId(FacultyId)) {
			if (employeeService.getEmployeeById(FacultyId).getRole().equalsIgnoreCase("trainer")) {
				System.out.println("Enter Course Id : ");
				int courseId = sc.nextInt();
				if (employeeService.validateId(courseId)) {
					if (trainingService.getTrainingById(courseId) != null) {
						System.out.println("Enter Start Date : ");
						String sDate = sc.next();
						System.out.println("Enter End Date : ");
						String eDate = sc.next();
						DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						LocalDate startDate = LocalDate.parse(sDate, format);
						LocalDate endDate = LocalDate.parse(eDate, format);
						Training training = new Training(courseId, FacultyId, startDate, endDate);
						Training addedTraining = trainingService.addTraining(training);
						if (addedTraining != null) {
							System.out.println("Training added");
						} else {
							System.out.println("Training not added");
						}
					} else
						System.out.println("Course id does not exist.");
				} else
					System.out.println("Course id not valid");

			} else
				System.out.println("Faculty Id does not exist");
		} else
			System.out.println("Faculty Id not valid");

	}

}
